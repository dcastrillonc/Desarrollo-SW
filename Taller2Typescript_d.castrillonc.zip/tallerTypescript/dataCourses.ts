import { Course } from './course.js';

export const dataCourses = [
  new Course("Ingeniería de SW", "Rubby Casallas", 4),
  new Course("Inglés 10A", "Edgar Garzón", 2),
  new Course("Lenguajes y Máquinas", "Silvia Takahashi", 1),
] 
  
