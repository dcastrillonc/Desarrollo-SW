import { student } from './student.js';
export var dataStudent = new student("Juan Martínez", 201923416, 1193580584, 19, "Cra. 68b #24-39", 3203009522);
