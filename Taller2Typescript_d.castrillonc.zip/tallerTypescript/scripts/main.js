import { dataCourses } from './dataCourses.js';
import { dataStudent } from './dataStudent.js';
var coursesTbody = document.getElementById('courses');
var studentTBody = document.getElementById('information');
var btnfilterByName = document.getElementById("button-filterByName");
var btnfilterByRange = document.getElementById("button-range");
var inputSearchBox = document.getElementById("search-box");
var inputMinimumBox = document.getElementById("minimum-range");
var inputMaximumBox = document.getElementById("maximum-range");
var totalCreditElm = document.getElementById("total-credits");
btnfilterByName.onclick = function () { return applyFilterByName(); };
btnfilterByRange.onclick = function () { return applyFilterCreditsRange(); };
renderCoursesInTable(dataCourses);
renderStudentInformation(dataStudent);
totalCreditElm.innerHTML = "<p style=\"text-align: center;\"> N\u00FAmero total cr\u00E9ditos: " + getTotalCredits(dataCourses) + "</p>";
function renderCoursesInTable(courses) {
    console.log('Desplegando cursos');
    courses.forEach(function (course) {
        var trElement = document.createElement("tr");
        trElement.innerHTML = "<td>" + course.name + "</td>\n                           <td>" + course.professor + "</td>\n                           <td>" + course.credits + "</td>";
        coursesTbody.appendChild(trElement);
    });
}
function renderStudentInformation(studentInfo) {
    var studentElement = document.getElementById("studentName");
    var trElement1 = document.createElement("tr");
    var trElement2 = document.createElement("tr");
    var trElement3 = document.createElement("tr");
    var trElement4 = document.createElement("tr");
    var trElement5 = document.createElement("tr");
    trElement1.innerHTML = "<th scope=\"row\">C\u00F3digo</th>\n                           <td>" + studentInfo.codigo + "</td>";
    trElement2.innerHTML = "<th scope=\"row\">C\u00E9dula</th>\n                           <td>" + studentInfo.cedula + "</td>";
    trElement3.innerHTML = "<th scope=\"row\">Edad</th>\n                            <td>" + studentInfo.edad + "</td>";
    trElement4.innerHTML = "<th scope=\"row\">Direcci\u00F3n</th>\n                            <td>" + studentInfo.direccion + "</td>";
    trElement5.innerHTML = "<th scope=\"row\">Tel\u00E9fono</th>\n                           <td>" + studentInfo.telefono + "</td>";
    studentTBody.appendChild(trElement1);
    studentTBody.appendChild(trElement2);
    studentTBody.appendChild(trElement3);
    studentTBody.appendChild(trElement4);
    studentTBody.appendChild(trElement5);
    studentElement.innerHTML = "" + studentInfo.nombre;
}
function applyFilterCreditsRange() {
    var strminimum = inputMinimumBox.value;
    var strmaximum = inputMaximumBox.value;
    var minimum = (strminimum == null) ? -1 : parseInt(strminimum);
    var maximum = (strmaximum == null) ? -1 : parseInt(strmaximum);
    clearCoursesInTable();
    var coursesFiltered = searchCourseByCreditsRange(minimum, maximum, dataCourses);
    renderCoursesInTable(coursesFiltered);
}
function applyFilterByName() {
    var text = inputSearchBox.value;
    text = (text == null) ? '' : text;
    clearCoursesInTable();
    var coursesFiltered = searchCourseByName(text, dataCourses);
    renderCoursesInTable(coursesFiltered);
}
function searchCourseByName(nameKey, courses) {
    return nameKey === '' ? dataCourses : courses.filter(function (c) {
        return c.name.match(nameKey);
    });
}
function searchCourseByCreditsRange(minimum, maximum, courses) {
    return minimum == -1 && maximum == -1 ? dataCourses : courses.filter(function (c) { return c.credits >= minimum && c.credits <= maximum; });
}
function getTotalCredits(courses) {
    var totalCredits = 0;
    courses.forEach(function (course) { return totalCredits = totalCredits + course.credits; });
    return totalCredits;
}
function clearCoursesInTable() {
    while (coursesTbody.hasChildNodes()) {
        if (coursesTbody.firstChild != null) {
            coursesTbody.removeChild(coursesTbody.firstChild);
        }
    }
}
