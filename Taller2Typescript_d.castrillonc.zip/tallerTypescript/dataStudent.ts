import { student } from './student.js';

export const dataStudent = new student("Daniela Castrillón Castro", 202011778, 1234768943, 19, "Calle falsa 321", 3246785943);