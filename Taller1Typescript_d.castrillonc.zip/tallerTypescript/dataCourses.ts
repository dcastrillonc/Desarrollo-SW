import { Course } from './course.js';

export const dataCourses = [
  new Course("Ingeniería de SW", "Rubby Casallas", 4),
  new Course("Inglés 10A", "Edgar Garzón", 2),
  new Course("Lenguajes y Máquinas", "Silvia Takahashi", 2),
  new Course("Infraestructura Computacional", "Harold Castro", 1),
  new Course("Cálculo Integral con Ecuaciones Diferenciales", "Maricarmen Martinez", 6)
]